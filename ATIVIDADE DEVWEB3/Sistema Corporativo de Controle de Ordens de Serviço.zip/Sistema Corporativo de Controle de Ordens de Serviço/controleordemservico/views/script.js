const API_URL = 'http://localhost:3000/api/os';
const osForm = document.getElementById('osForm');
const btnSubmit = document.getElementById('btnSubmit');
const btnCancelEdit = document.getElementById('btnCancelEdit');

// ---------------------- FUNÇÕES CORE ----------------------

// Função central para buscar e listar OS, incluindo filtros
async function fetchOS(filters = {}) {
    try {
        // Constrói a URL com base nos filtros
        const params = new URLSearchParams(filters).toString();
        const url = `${API_URL}?${params}`;
        
        const response = await fetch(url);
        const orders = await response.json();
        const osListDiv = document.getElementById('osList');
        osListDiv.innerHTML = '';

        orders.forEach(os => {
            // Formatação de Datas
            const openingDate = new Date(os.openingDate).toLocaleDateString('pt-BR');
            const deadlineDate = os.estimatedDeadline ? new Date(os.estimatedDeadline).toLocaleDateString('pt-BR') : '-';

            // Classe dinâmica para cores de Status
            const statusClass = `cell-status-${os.status.replace(/\s/g, '-')}`;
            // Classe dinâmica para cores de Prioridade
            const priorityClass = `cell-priority-${os.priority}`;


            const div = document.createElement('div');
            div.className = 'os-item';
            div.innerHTML = `
            <span class="cell-id">${os._id.substring(0, 4)}...</span>
            <span class="cell-title" title="${os.description}">
                ${os.title} 
                <div style="font-size: 0.8em; color: #777;">Abertura: ${openingDate}</div>
            </span>
            <span class="${statusClass}">${os.status.toUpperCase()}</span>
            <span class="${priorityClass}">${os.priority.toUpperCase()}</span>
            <span>${os.requesterSector}</span>
            <span class="cell-deadline">${deadlineDate}</span>
            <span class="cell-value">R$${os.serviceValue.toFixed(2)}</span>
            <div class="actions">
                <button class="btn-alterar" onclick="loadOSForEdit('${os._id}')">Alterar</button>
                <button class="btn-excluir" onclick="deleteOS('${os._id}')">Excluir</button>
            </div>
        `;
            osListDiv.appendChild(div);
        });

    } catch (error) {
        console.error('Erro ao buscar Ordens de Serviço:', error);
    }
}

// Função disparada ao mudar filtros ou buscar por título
function filterOS() {
    const filters = {
        title: document.getElementById('filterTitle').value,
        status: document.getElementById('filterStatus').value,
        priority: document.getElementById('filterPriority').value,
        // setor não foi adicionado no frontend para simplificar, mas seria 'sector: document.getElementById('filterSector').value,'
    };
    // Remove filtros vazios
    Object.keys(filters).forEach(key => filters[key] === '' && delete filters[key]);
    
    fetchOS(filters);
}

// ... Funções fetchOS, filterOS omitidas por estarem corretas após as alterações anteriores ...

// Função para salvar (POST) ou atualizar (PUT) OS
async function saveOrUpdateOS(event) {
    event.preventDefault();

    const id = document.getElementById('osId').value;
    const deadlineInput = document.getElementById('estimatedDeadline').value;

    // Validação de campos obrigatórios (mantida)
    if (!document.getElementById('title').value || 
        !document.getElementById('description').value ||
        !document.getElementById('priority').value ||
        !document.getElementById('requesterSector').value ||
        !document.getElementById('serviceValue').value) {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return;
    }

    const osData = {
        title: document.getElementById('title').value,
        description: document.getElementById('description').value,
        priority: document.getElementById('priority').value,
        responsible: document.getElementById('responsible').value || undefined, // Envia undefined se vazio (opcional)
        requesterSector: document.getElementById('requesterSector').value,
        serviceValue: parseFloat(document.getElementById('serviceValue').value),
        
        // CRIAÇÃO (POST): Status é 'aberta'. EDIÇÃO (PUT) será definida abaixo.
        status: 'aberta', 
        
        estimatedDeadline: deadlineInput ? new Date(deadlineInput + 'T00:00:00').toISOString() : undefined,
    };

    let method = 'POST';
    let url = API_URL;

    if (id) {
        method = 'PUT'; // Modo de edição
        url = `${API_URL}/${id}`;
        
        // ✅ CORREÇÃO: Se estiver editando, o status vem do SELECT VISÍVEL (statusSelect)
        osData.status = document.getElementById('statusSelect').value; 
    }

    const response = await fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(osData),
    });

    if (response.ok) {
        clearForm();
        await fetchOS();
        alert('Ordem de Serviço salva com sucesso!');
    } else {
        const errorData = await response.json();
        alert('Erro ao salvar OS: ' + (errorData.details || errorData.error || 'Verifique o console para mais detalhes.'));
    }
}

// ... (Restante do script.js com loadOSForEdit e clearForm mantidos) ...

// Função para pré-carregar OS para edição
async function loadOSForEdit(id) {
    try {
        const response = await fetch(`${API_URL}/${id}`);
        const os = await response.json();

        document.getElementById('osId').value = os._id;
        document.getElementById('title').value = os.title;
        document.getElementById('description').value = os.description;
        document.getElementById('priority').value = os.priority;
        document.getElementById('responsible').value = os.responsible || '';
        document.getElementById('requesterSector').value = os.requesterSector;
        document.getElementById('serviceValue').value = os.serviceValue.toFixed(2);
        
       // 1. Exibir o select de Status
       const statusSelect = document.getElementById('statusSelect');
       statusSelect.style.display = 'block';
       
       // 2. Pré-selecionar o status atual do banco de dados
       statusSelect.value = os.status;

        // Formata Prazo Estimado (Opcional)
        if (os.estimatedDeadline) {
            const dateOnly = new Date(os.estimatedDeadline).toISOString().split('T')[0];
            document.getElementById('estimatedDeadline').value = dateOnly;
        } else {
             document.getElementById('estimatedDeadline').value = '';
        }

        btnSubmit.textContent = 'Salvar Alterações';
        btnCancelEdit.style.display = 'inline-block';
        alert(`Editando OS: ${os.title}. Status Atual: ${os.status.toUpperCase()}`);

    } catch (error) {
        console.error('Erro ao carregar OS para edição:', error);
        alert('Erro ao carregar Ordem de Serviço.');
    }
}

// Função para deletar OS
async function deleteOS(id) {
    if (!confirm('Esta OS será permanentemente excluída. Continuar? (Lembre-se: Apenas ordens CONCLUÍDAS podem ser excluídas)')) return;

    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE',
        });

        if (response.status === 204) {
            await fetchOS(); 
            alert('Ordem de Serviço excluída com sucesso!'); 
        } else {
            const errorData = await response.json();
            alert('Erro ao excluir OS: ' + (errorData.error || 'Verifique o console para mais detalhes.'));
        }
    } catch (error) {
        console.error('Erro ao deletar OS:', error);
    }
}

// Função para limpar o formulário e reverter para o modo de cadastro
function clearForm() {
    osForm.reset();
    document.getElementById('osId').value = '';
    
    // Oculta o seletor de status no modo de cadastro
    document.getElementById('statusSelect').style.display = 'none';
    document.getElementById('statusSelect').value = 'aberta'; // Reseta o valor
    
    btnSubmit.textContent = 'Cadastrar OS';
    btnCancelEdit.style.display = 'none';
}


// ---------------------- EVENTOS ----------------------

osForm.addEventListener('submit', saveOrUpdateOS);
btnCancelEdit.addEventListener('click', clearForm);

// Carregar OS ao iniciar a página 
window.addEventListener('DOMContentLoaded', () => {
    fetchOS();
});