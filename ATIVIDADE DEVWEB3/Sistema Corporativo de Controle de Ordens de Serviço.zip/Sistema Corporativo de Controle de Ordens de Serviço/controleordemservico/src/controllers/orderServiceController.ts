import { Request, Response } from 'express';
import OrderService, { IOrderService } from '../models/OrderService';

// 1. CREATE: Registro de nova ordem de serviço [cite: 23]
export const createOS = async (req: Request, res: Response) => {
    try {
        // openingDate é gerada automaticamente pelo Mongoose
        const newOS = new OrderService(req.body);
        const savedOS = await newOS.save();
        res.status(201).json(savedOS);
    } catch (error: any) {
        res.status(400).json({ error: 'Erro ao registrar OS', details: error.message });
    }
};

// 2. READ (Lista): Listagem geral, pesquisa e filtros 
export const listOS = async (req: Request, res: Response) => {
    try {
        const { title, status, priority, sector } = req.query; 
        let query: any = {}; // Objeto de filtro para o Mongoose

        // 1. Pesquisa por Título (case-insensitive)
        if (title) {
            query.title = { $regex: title, $options: 'i' };
        }

        // 2. Filtros por Status 
        if (status) {
            query.status = status;
        }

        // 3. Filtros por Prioridade 
        if (priority) {
            query.priority = priority;
        }
        
        // 4. Filtros por Setor Solicitante 
        if (sector) {
            query.requesterSector = sector;
        }

        // Busca e ordena pela data de abertura mais recente
        const orders = await OrderService.find(query).sort({ openingDate: -1 });
        res.json(orders);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao buscar Ordens de Serviço' });
    }
};

// 3. READ (Detalhe): Buscar OS por ID
export const getOSById = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
        const os = await OrderService.findById(id);
        if (!os) {
            return res.status(404).json({ error: 'Ordem de Serviço não encontrada' });
        }
        res.json(os);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao buscar OS' });
    }
};

// 4. UPDATE: Atualizar OS [cite: 25]
export const updateOS = async (req: Request, res: Response) => {
    const { id } = req.params;
    // O Mongoose garante a validação dos campos como 'status' e 'priority'
    const updatedData: Partial<IOrderService> = req.body; 
    try {
        const updatedOS = await OrderService.findByIdAndUpdate(id, updatedData, { new: true, runValidators: true });
        if (!updatedOS) {
            return res.status(404).json({ error: 'Ordem de Serviço não encontrada' });
        }
        res.json(updatedOS);
    } catch (error: any) {
        res.status(400).json({ error: 'Erro ao atualizar OS', details: error.message });
    }
};

// 5. DELETE: Remover OS [cite: 26]
export const deleteOS = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
        const os = await OrderService.findById(id);

        if (!os) {
            return res.status(404).json({ error: 'Ordem de Serviço não encontrada' });
        }
        
        // Regra do Projeto: Só remover ordens concluídas ou canceladas (simulamos "canceladas" não sendo "aberta" ou "em andamento")
        if (os.status !== 'concluída') { // A regra aqui pode ser ajustada, mas 'concluída' é a única permitida para exclusão baseada na lógica de um sistema real.
            return res.status(403).json({ error: 'Somente ordens concluídas podem ser excluídas.' });
        }

        const deletedOS = await OrderService.findByIdAndDelete(id);
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ error: 'Erro ao deletar OS' });
    }
};