import mongoose, { Schema, Document } from "mongoose";

// Interface TypeScript para o documento do MongoDB (Ordem de Serviço)
export interface IOrderService extends Document {
    title: string; // Título (obrigatório) 
    description: string; // Descrição (obrigatório) 
    openingDate: Date; // Data de abertura (automática) 
    status: 'aberta' | 'em andamento' | 'concluída'; // Status (obrigatório com valores permitidos) 
    priority: 'baixa' | 'média' | 'alta'; // Prioridade (obrigatório com valores permitidos) 
    responsible?: string; // Responsável (opcional) 
    requesterSector: string; // Setor solicitante (obrigatório) 
    estimatedDeadline?: Date; // Prazo estimado (opcional) 
    serviceValue: number; // Valor do Serviço (obrigatório) 
}

// Schema do Mongoose
const OrderServiceSchema: Schema = new Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    openingDate: { type: Date, default: Date.now, required: true }, // 
    status: { 
        type: String, 
        required: true, 
        enum: ['aberta', 'em andamento', 'concluída'], // Validação de valores 
        default: 'aberta' 
    },
    priority: { 
        type: String, 
        required: true, 
        enum: ['baixa', 'média', 'alta'] // Validação de valores 
    },
    responsible: { type: String, required: false }, // 
    requesterSector: { type: String, required: true }, // 
    estimatedDeadline: { type: Date, required: false }, // 
    serviceValue: { 
        type: Number, 
        required: true, 
        min: [0, 'O valor do serviço deve ser positivo.'] // Valor Decimal (usamos Number para MongoDB) 
    },
});

export default mongoose.model<IOrderService>('OrderService', OrderServiceSchema);