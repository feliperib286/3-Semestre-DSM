import { Router } from 'express';
import { 
    createOS, 
    listOS, 
    getOSById,
    updateOS, 
    deleteOS
} from '../controllers/orderServiceController';

const router = Router();

// Rotas CRUD de Ordens de Serviço
router.post('/', createOS); // Criar [cite: 23]
router.get('/', listOS); // Listar, Pesquisar e Filtrar 
router.get('/:id', getOSById); // Buscar por ID
router.put('/:id', updateOS); // Atualizar [cite: 25]
router.delete('/:id', deleteOS); // Excluir [cite: 26]

export default router;