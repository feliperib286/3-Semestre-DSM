import 'dotenv/config'; // Importa e carrega as variáveis do .env no início
import express from 'express';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import cors from 'cors';
import orderServiceRoutes from './routes/orderServiceRoutes'; 

const app = express();
// Lendo as variáveis do arquivo .env
const PORT = process.env.PORT || 3000; // Define 3000 como fallback
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/ordens_servico'; 

// Middleware
app.use(bodyParser.json());
app.use(cors());
app.use(express.json());
app.use(express.static('views'));

// Conectar ao MongoDB 
mongoose.connect(MONGODB_URI)
    .then(() => console.log(`MongoDB conectado ao DB: ${MONGODB_URI.split('/').pop()}`))
    .catch(err => console.log('Erro ao conectar ao MongoDB', err));

// Usar as rotas de Ordens de Serviço, prefixando com '/api/os'
app.use('/api/os', orderServiceRoutes);

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});