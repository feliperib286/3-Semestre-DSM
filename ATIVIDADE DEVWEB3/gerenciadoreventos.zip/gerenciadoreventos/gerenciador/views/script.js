const API_URL = 'http://localhost:3000/api/events';
const eventForm = document.getElementById('eventForm');
const btnSubmit = document.getElementById('btnSubmit');
const btnCancelEdit = document.getElementById('btnCancelEdit');

// ---------------------- FUNÇÕES CORE ----------------------

// Função para buscar e listar todos os eventos
async function fetchEvents() {
    try {
        const response = await fetch(API_URL);
        const events = await response.json();
        const eventsListDiv = document.getElementById('eventsList');
        eventsListDiv.innerHTML = '';

        events.forEach(event => {
            const date = new Date(event.date);
            const formattedDate = date.toLocaleDateString('pt-BR');

            const div = document.createElement('div');
            div.className = 'event-item';
            div.innerHTML = `
            <span class="cell-title">${event.title}</span>
            <span class="cell-location">${event.location}</span>
            <span class="cell-description">${event.description || '-'}</span>
            <span class="cell-amount">R$${event.amount.toFixed(2)}</span>
            <span class="cell-date">${formattedDate}</span>
            
            <div class="actions">
                <button class="btn-alterar" onclick="loadEventForEdit('${event._id}')">Alterar</button>
                <button class="btn-excluir" onclick="deleteEvent('${event._id}')">Excluir</button>
            </div>
        `;
            eventsListDiv.appendChild(div);
        });

    } catch (error) {
        console.error('Erro ao buscar eventos:', error);
    }
}

// Função para salvar (POST) ou atualizar (PUT) evento 
async function saveOrUpdateEvent(event) {
    event.preventDefault();

    const id = document.getElementById('eventId').value;
    const dateInput = document.getElementById('date').value;

    // Validação do lado do cliente (Requisitos: Title, Date, Location, Amount)
    if (!document.getElementById('title').value || !document.getElementById('amount').value || !dateInput || !document.getElementById('location').value) {
        alert('Por favor, preencha todos os campos obrigatórios (Título, Local, Data, Valor).');
        return;
    }

    // Converte a data no formato YYYY-MM-DD para o formato ISO Date
    const eventData = {
        title: document.getElementById('title').value,
        description: document.getElementById('description').value, // Opcional
        location: document.getElementById('location').value, // Novo campo
        amount: parseFloat(document.getElementById('amount').value),
        date: dateInput ? new Date(dateInput + 'T00:00:00').toISOString() : new Date().toISOString(),
    };

    let method = 'POST';
    let url = API_URL;

    if (id) {
        method = 'PUT'; // Modo de edição
        url = `${API_URL}/${id}`;
    }

    const response = await fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventData),
    });

    if (response.ok) {
        clearForm();
        await fetchEvents(); // Atualiza a lista
        alert('Evento salvo com sucesso!'); // Mensagem de sucesso [cite: 27]
    } else {
        const errorData = await response.json();
        alert('Erro ao salvar evento: ' + (errorData.details || 'Verifique o console para mais detalhes.')); // Mensagem de erro [cite: 27]
    }
}

// Função para pré-carregar evento para edição 
async function loadEventForEdit(id) {
    try {
        const response = await fetch(`${API_URL}/${id}`);
        const event = await response.json();

        document.getElementById('eventId').value = event._id;
        document.getElementById('title').value = event.title; // Novo campo
        document.getElementById('description').value = event.description || ''; // Opcional
        document.getElementById('location').value = event.location; // Novo campo
        document.getElementById('amount').value = event.amount.toFixed(2);

        // Formata a data ISO (AAAA-MM-DDTHH:MM:SS...) para AAAA-MM-DD
        const dateOnly = new Date(event.date).toISOString().split('T')[0];
        document.getElementById('date').value = dateOnly;

        btnSubmit.textContent = 'Salvar Alterações';
        btnCancelEdit.style.display = 'inline-block';
    } catch (error) {
        console.error('Erro ao carregar evento para edição:', error);
        alert('Erro ao carregar evento.');
    }
}

// Função para deletar evento 
async function deleteEvent(id) {
    if (!confirm('Tem certeza que deseja EXCLUIR este evento?')) return;

    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE',
        });

        if (response.status === 204) {
            await fetchEvents(); // Atualiza a lista
            alert('Evento excluído com sucesso!'); // Mensagem de sucesso [cite: 27]
        } else {
            alert('Erro ao excluir evento.'); // Mensagem de erro [cite: 27]
        }
    } catch (error) {
        console.error('Erro ao deletar evento:', error);
    }
}

// Função para limpar o formulário e reverter para o modo de cadastro
function clearForm() {
    eventForm.reset();
    document.getElementById('eventId').value = '';
    btnSubmit.textContent = 'Cadastrar Evento';
    btnCancelEdit.style.display = 'none';
}


// ---------------------- EVENTOS ----------------------

// Disparar funções ao enviar o formulário
eventForm.addEventListener('submit', saveOrUpdateEvent);

// Disparar função para cancelar edição
btnCancelEdit.addEventListener('click', clearForm);

// Carregar eventos ao iniciar a página 
window.addEventListener('DOMContentLoaded', () => {
    fetchEvents();
});