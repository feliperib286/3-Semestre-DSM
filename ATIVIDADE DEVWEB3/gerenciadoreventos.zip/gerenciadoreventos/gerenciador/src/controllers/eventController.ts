import { Request, Response } from 'express';
import Event, { IEvent } from '../models/Event';

// 1. CREATE: Inserir novo evento [cite: 15]
export const createEvent = async (req: Request, res: Response) => {
    try {
        const newEvent = new Event(req.body);
        const savedEvent = await newEvent.save();
        res.status(201).json(savedEvent);
    } catch (error: any) {
        res.status(400).json({ error: 'Erro ao cadastrar evento', details: error.message });
    }
};

// 2. READ (Lista): Listar todos os eventos ou buscar por título 
export const listEvents = async (req: Request, res: Response) => {
    try {
        const { title } = req.query; // Captura o parâmetro de busca 'title'
        let query = {};

        // Se houver título na query, adiciona filtro com expressão regular (case-insensitive)
        if (title) {
            query = { title: { $regex: title, $options: 'i' } };
        }

        // Busca, filtra e ordena por data mais recente
        const events = await Event.find(query).sort({ date: -1 });
        res.json(events);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao buscar eventos' });
    }
};

// 3. READ (Detalhe): Buscar evento por ID
export const getEventById = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
        const event = await Event.findById(id);
        if (!event) {
            return res.status(404).json({ error: 'Evento não encontrado' });
        }
        res.json(event);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao buscar evento' });
    }
};

// 4. UPDATE: Atualizar evento [cite: 17]
export const updateEvent = async (req: Request, res: Response) => {
    const { id } = req.params;
    const updatedData: Partial<IEvent> = req.body;
    try {
        const updatedEvent = await Event.findByIdAndUpdate(id, updatedData, { new: true, runValidators: true });
        if (!updatedEvent) {
            return res.status(404).json({ error: 'Evento não encontrado' });
        }
        res.json(updatedEvent);
    } catch (error: any) {
        res.status(400).json({ error: 'Erro ao atualizar evento', details: error.message });
    }
};

// 5. DELETE: Remover evento [cite: 18]
export const deleteEvent = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
        const deletedEvent = await Event.findByIdAndDelete(id);
        if (!deletedEvent) {
            return res.status(404).json({ error: 'Evento não encontrado' });
        }
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ error: 'Erro ao deletar evento' });
    }
};