import express from 'express';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import cors from 'cors';
// Importa o novo arquivo de rotas
import eventRoutes from './routes/eventRoutes'; 

const app = express();
const PORT = 3000;
// Nome do Banco de Dados alterado para 'evento' 
const MONGODB_URI = 'mongodb://localhost:27017/evento'; 

// Middleware
app.use(bodyParser.json());
app.use(cors());
app.use(express.json());
app.use(express.static('views'));

// Conectar ao MongoDB 
mongoose.connect(MONGODB_URI)
    .then(() => console.log('MongoDB conectado ao DB: evento'))
    .catch(err => console.log('Erro ao conectar ao MongoDB', err));

// Usar as rotas de eventos, prefixando com '/api/events'
app.use('/api/events', eventRoutes);

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});