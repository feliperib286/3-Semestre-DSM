import { Router } from 'express';
import { 
    createEvent, 
    listEvents, 
    getEventById,
    updateEvent, 
    deleteEvent
} from '../controllers/eventController';

const router = Router();

// Rotas CRUD de Eventos [cite: 14, 15, 16, 17, 18]
router.post('/', createEvent); // Cadastrar
router.get('/', listEvents); // Listar todos (ou pesquisar por título)
router.get('/:id', getEventById); // Buscar por ID
router.put('/:id', updateEvent); // Alterar
router.delete('/:id', deleteEvent); // Excluir

export default router;