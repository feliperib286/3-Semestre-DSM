import mongoose, { Schema, Document } from "mongoose";

// Interface TypeScript para o documento do MongoDB (Evento)
export interface IEvent extends Document {
    title: string; 
    description?: string; 
    date: Date; 
    location: string; 
    amount: number; 
}

// Schema do Mongoose (estrutura do banco de dados)
const EventSchema: Schema = new Schema({
    title: { type: String, required: true },
    description: { type: String, required: false }, // Agora opcional
    date: { type: Date, required: true, default: Date.now },
    location: { type: String, required: true }, // Novo campo
    amount: { 
        type: Number, 
        required: true, 
        min: [0.01, 'O valor do evento deve ser positivo.'] 
    }, 
});

// Exportar o modelo Mongoose (Renomeado de Expense para Event)
export default mongoose.model<IEvent>('Event', EventSchema);